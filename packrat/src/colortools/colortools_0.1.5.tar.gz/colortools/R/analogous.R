#' @export
analogous <-
function(color, plot=TRUE, bg="white", labcol=NULL, cex=0.8, title=TRUE) 
{
	adjacent(color, plot=plot, bg=bg, labcol=labcol, cex=cex, title=title)
}
