#' @export
opposite <-
function(color, plot=TRUE, bg="white", labcol=NULL, cex=0.8, title=TRUE) 
{
	complementary(color, plot=plot, bg=bg, labcol=labcol, cex=cex, title=title)
}
