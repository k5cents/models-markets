0.4.0
* Nascent "Scrape API" support

0.3.1 
* sped up get_timemap() and made it more robuse in handling malformed records
  (https://stackoverflow.com/questions/52364134/r-scraping-dynamic-links-with-rvest/52365094?noredirect=1#comment91678810_52365094)

0.3.0
* `read_memento()`, appveyor and more tests

0.2.0
* Tests

0.1.0
* Initial release
